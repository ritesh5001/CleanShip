repo: ritesh5001/CleanShip
branch: main

## Last sync

date: 2026-09-08T11:22:00Z

### Updated in this project

- Designed three phone-grid directions to replace the horizontally-scrolling supervisor grid.
- Rebuilt the customer share page on the marine tokens: navy ground, schematic hull instead of the 3D model.
- Added the office console and both sign-in doors; the customer link opens with no IMO challenge.
- Flagged two palette drifts in the running app: the Expo theme's slate/indigo values and the share page's near-black + sky/emerald.

## Screen map

| Project screen | Built from |
| --- | --- |
| 1a / 1b / 1c — supervisor grid | mobile/app/vessels/, mobile/src/theme.ts, mobile/src/queue.ts, mobile/src/sync.ts |
| 1d — office console | frontend/src/app/cleantrack/admin/, frontend/src/app/cleantrack/admin/vessels/ |
| 1e — customer link | frontend/src/app/cleantrack/j/[token]/page.tsx, frontend/src/components/cleantrack/client-vessel-view |
| 1f — crew door | mobile/app/login.tsx, frontend/src/app/cleantrack/login/page.tsx |
| 1f — office door | frontend/src/app/admin/login/page.tsx |
| 1f — link lifecycle | frontend/src/app/cleantrack/j/[token]/actions.ts (IMO gate removed per client direction) |
| Tokens (colour, type, spacing) | cleanship design system/tokens/ |
